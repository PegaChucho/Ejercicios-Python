from setuptools import setup

setup(

	name="paqueteCalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Jesús",
	author_email="jesus_perez_0123@hotmail.com",
	url="www.xpetrus.com",
	packages=["paquete","paquete.subpaquete_redondeo_potencia"]
	)
