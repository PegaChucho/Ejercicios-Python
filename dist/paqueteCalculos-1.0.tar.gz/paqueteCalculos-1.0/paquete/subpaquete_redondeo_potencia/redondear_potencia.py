
def potencia(base,exp):
	print("El resultado de la poencia es: ", (base**exp))

def redondear(numero):
	print("El resultado es: ", round(numero))