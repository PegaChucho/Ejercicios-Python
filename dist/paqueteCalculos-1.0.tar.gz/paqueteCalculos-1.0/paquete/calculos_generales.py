def sumar(op1,op2):
	print("El resultado de la suma es: ", (op1+op2))

def restar(op1,op2):
	print("El resultado de la resta es: ", (op1-op2))

def multiplicar(op1,op2):
	print("El resultado de la multiplicación es: ", (op1*op2))

def dividir(op1,op2):
	print("El resultado de la división es: ", (op1/op2))

def potencia(base,exp):
	print("El resultado de la poencia es: ", (base**exp))

def redondear(numero):
	print("El resultado es: ", round(numero))